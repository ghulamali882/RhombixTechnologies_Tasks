function showMessage() {
    alert("Thank you for Visiting My Portfolio!");
}
